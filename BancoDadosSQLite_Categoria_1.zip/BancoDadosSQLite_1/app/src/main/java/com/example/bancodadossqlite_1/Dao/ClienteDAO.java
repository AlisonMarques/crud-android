package com.example.bancodadossqlite_1.Dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.bancodadossqlite_1.Model.Cliente;

import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {

    private final String TABELA = "cliente";
    private final String[] CAMPOS = {"id, nome, fone, email, observacao, id_categoria"};

    private Conexao conexao;
    private SQLiteDatabase banco;

    //Construtor
    public ClienteDAO(Context context) {
        conexao = new Conexao(context);
        banco = conexao.getWritableDatabase();
    }

    private ContentValues preencherValores(Cliente cliente) {
        ContentValues values = new ContentValues();

        values.put("nome", cliente.getNome());
        values.put("fone", cliente.getFone());
        values.put("email", cliente.getEmail());
        values.put("observacao", cliente.getObservacao());
        values.put("id_categoria", cliente.getCategoria().getId());

        return values;
    }

    // MÉTODOS DO CRUD

    public long inserir(Cliente cliente) {
        ContentValues values = preencherValores(cliente);
        return banco.insert(TABELA, null, values);
    }

    public long alterar(Cliente cliente) {
        ContentValues values = preencherValores(cliente);
        return banco.update(TABELA, values, "id = ?", new String[]{String.valueOf(cliente.getId())});
    }

    public long excluir(Cliente cliente) {
        return banco.delete(TABELA, "id = ?", new String[]{String.valueOf(cliente.getId())});
    }

    public List<Cliente> listar() {
        Cursor c = banco.query(TABELA, CAMPOS, null, null, null, null, null);

        List<Cliente> lista = new ArrayList<>();
        while (c.moveToNext()) {
            Cliente cliente = new Cliente();
            cliente.setId((int) c.getLong(0));
            cliente.setNome(c.getString(1));
            cliente.setFone(c.getString(2));
            cliente.setEmail(c.getString(3));
            cliente.setObservacao(c.getString(4));
            cliente.getCategoria().setId(c.getInt(5));

            // adicionando todo o cliente ao listar
            lista.add(cliente);
        }

        return lista;
    }
}

