package com.example.bancodadossqlite_1.Dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Conexao extends SQLiteOpenHelper {

    private static final String NAME = "banco.db";
    private static final String TABELAC = "cliente";
    private static final String TABELACATE = "categoria";

    private static final int VERSION = 1;

    private static final String SQL_CREATE_CATEGORIA = "create table TABELACATE ( " +
            "id integer primary key autoincrement, "  +
            "nome varchar(50)" + ");";

    // criando o SQL para a tabela cliente com os seus atributos
    private static final String SQL_CREATE_CLIENTE = "create table TABELAC ( " +
            "id integer primary key autoincrement, " + "nome varchar(50), " +
            "fone varchar(20), " +
            "email varchar(50), " +
            "observacao text, " +
            "id_categoria integer, " +
            "constraint rel_categoria_cliente foreign key (id_categoria) references categoria(id) " + ");";

    // Construtor
    public Conexao(@Nullable Context context) {
        super(context, NAME, null, VERSION);
    }

    // Executando o SQL para criar a tabela cliente e conexao com o banco de dados
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_CATEGORIA);
        db.execSQL(SQL_CREATE_CLIENTE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
       db.execSQL("DROP TABLE IF EXISTS " + TABELACATE);
        db.execSQL("DROP TABLE IF EXISTS " + TABELAC);

        onCreate(db);
    }
}
