package com.example.bancodadossqlite_1.Model;

import java.io.Serializable;

public class Cliente implements Serializable {

    private int id;
    private String nome;
    private String fone;
    private String email;
    private String observacao;
    private Categoria categoria;




    //Construtor padrão
    public Cliente() {
        categoria = new Categoria();

    }

    // Construtor com parâmetros
//    public Cliente(int id, String nome, String fone, String email, String observacao) {
//        this.id = id;
//        this.nome = nome;
//        this.fone = fone;
//        this.email = email;
//        this.observacao = observacao;
//    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return
                " Nome: " + getNome() + "\n " + "Fone: " + getFone() + "\n " +
                        "E-mail: " + getEmail() + "\n " + "Obs: " + getObservacao();
    }


}

